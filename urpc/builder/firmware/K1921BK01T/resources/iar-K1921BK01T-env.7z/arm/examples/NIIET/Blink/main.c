#include "LED.h"

#include "stdint.h"

void delay(uint32_t x)
{
  uint32_t i;
  for(i=0;i<x;i++){};  
}

int main()
{
  unsigned char i=0;
  
  
  
  LED_Init();
  //LED_On(4);
  while(1)
  {
    if(i&0x8)
      LED_Out(1<<(i&0x7));
    else
      LED_Out(0x80>>(i&0x7));
     
    delay(0x80000);
    i++;
  }
}
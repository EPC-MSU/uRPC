/*----------------------------------------------------------------------------
 * Name:    LED.c
 * Purpose: Low Level LED functions on Board NIIET and LDMSYSTEM
 * Note(s): 
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2011 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#include "K1921BK01T.h"                      /* K1921BK01T definitions            */
#include "LED.h"

//#define BOARD_LDM

#define GPIO_PIN2  	(1 << 2)
#define GPIO_PIN3  	(1 << 3)
#define GPIO_PIN13  	(1 << 13)
#define GPIO_PIN14  	(1 << 14) 
#define GPIO_PIN15  	(1 << 15)
#define GPIO_PIN8_15  	0xFF00
/*----------------------------------------------------------------------------
  initialize LED Pins
 *----------------------------------------------------------------------------*/
void LED_Init (void) {
#ifdef BOARD_LDM
  /* configure pins PC.13,PC.14,PC.15,PD.13,PD.14,PD.15,PE.2,PE.3  as output  on Board LDM-HELPER-NIIET*/
  NT_COMMON_REG->GPIODENC |= (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15); 	/* enable pins in GPIOC */
  NT_COMMON_REG->GPIODEND |= (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15);  	/* enable pins in GPIOD */
  NT_COMMON_REG->GPIODENE |= (GPIO_PIN2 | GPIO_PIN3);  					/* enable pins in GPIOE */
  NT_GPIOC->OUTENSET = (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15);			/* enable OUTPUT pins in GPIOC */
  NT_GPIOD->OUTENSET = (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15);			/* enable OUTPUT pins in GPIOD */
  NT_GPIOE->OUTENSET = (GPIO_PIN2 | GPIO_PIN3);							/* enable OUTPUT pins in GPIOE */
  NT_GPIOC->ALTFUNCCLR = (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15);		/* disable ALTFUNCTION pins in GPIOC */
  NT_GPIOD->ALTFUNCCLR = (GPIO_PIN13 | GPIO_PIN14 | GPIO_PIN15);		/* disable ALTFUNCTION pins in GPIOD */
  NT_GPIOE->ALTFUNCCLR = (GPIO_PIN2 | GPIO_PIN3);						/* disable ALTFUNCTION pins in GPIOE */
#else
  /* configure pins PG.8,PG.9,PG.10,PG.11,PG.12,PG.13,PG.14,PG.15 as output on Board NIIET*/
  NT_COMMON_REG->GPIODENG |= GPIO_PIN8_15; 		/* enable pins in GPIOG */
  NT_GPIOG->OUTENSET = GPIO_PIN8_15;			/* enable OUTPUT pins in GPIOG */
  NT_GPIOG->ALTFUNCCLR = GPIO_PIN8_15;			/* disable ALTFUNCTION pins in GPIOG */
#endif
  LED_Out (0);                               /* switch LEDs off               */
}


/*----------------------------------------------------------------------------
  Function that turns on requested LED
 *----------------------------------------------------------------------------*/
void LED_On (unsigned int num) {

  if (num < LED_NUM) {
#ifdef BOARD_LDM
   switch (num){
  	case 0: NT_GPIOC->MASKHIGHBYTE[0x20] =0xFF00; break;
  	case 1: NT_GPIOC->MASKHIGHBYTE[0x40] =0xFF00; break;
  	case 2: NT_GPIOC->MASKHIGHBYTE[0x80] =0xFF00; break;
  	case 3: NT_GPIOD->MASKHIGHBYTE[0x20] =0xFF00; break;
  	case 4: NT_GPIOD->MASKHIGHBYTE[0x40] =0xFF00; break;
  	case 5: NT_GPIOD->MASKHIGHBYTE[0x80] =0xFF00; break;
  	case 6: NT_GPIOE->MASKLOWBYTE[0x04] =0x00FF; break;
  	case 7: NT_GPIOE->MASKLOWBYTE[0x08] =0x00FF; break;
  	} 	
#else
  NT_GPIOG->MASKHIGHBYTE[(num <<4)] =0xFF00;
#endif
  }
}

/*----------------------------------------------------------------------------
  Function that turns off requested LED
 *----------------------------------------------------------------------------*/
void LED_Off (unsigned int num) {

  if (num < LED_NUM) {
#ifdef BOARD_LDM
   switch (num){
  	case 0: NT_GPIOC->MASKHIGHBYTE[0x20] =0x0000; break;
  	case 1: NT_GPIOC->MASKHIGHBYTE[0x40] =0x0000; break;
  	case 2: NT_GPIOC->MASKHIGHBYTE[0x80] =0x0000; break;
  	case 3: NT_GPIOD->MASKHIGHBYTE[0x20] =0x0000; break;
  	case 4: NT_GPIOD->MASKHIGHBYTE[0x40] =0x0000; break;
  	case 5: NT_GPIOD->MASKHIGHBYTE[0x80] =0x0000; break;
  	case 6: NT_GPIOE->MASKLOWBYTE[0x04] =0x0000; break;
  	case 7: NT_GPIOE->MASKLOWBYTE[0x08] =0x0000; break;
  	} 
#else
  NT_GPIOG->MASKHIGHBYTE[(num <<4)] =0x0000;
#endif
  }
}

/*----------------------------------------------------------------------------
  Function that outputs value to LEDs
 *----------------------------------------------------------------------------*/
void LED_Out(unsigned int value) {
  int i;

  for (i = 0; i < LED_NUM; i++) {
    if (value & (1<<i)) {
      LED_On (i);
    } else {
      LED_Off(i);
    }
  }
}

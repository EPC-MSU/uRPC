/*----------------------------------------------------------------------------
 * Name:    Serial.c
 * Purpose: Low Level Serial Routines
 * Note(s): on board LDMSYSTEM is default use USART2 interface (microUSB X9)
 *          for use configurate on board LDMSYSTEM is uncomment #define BOARD_LDMSYS
 *----------------------------------------------------------------------------
 * This file for use printf IAR.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2015 NIIET. All rights reserved.
 *----------------------------------------------------------------------------*/

#include <NIIET\K1921BK01T.h>                       /* K1921BK01T definitions         */
#define BOARD_LDMSYS

#ifndef FUARTCLK
  #ifdef BOARD_LDMSYS
    #define FUARTCLK 16000000 /*UL*/
  #else  
    #define FUARTCLK 12000000 /*UL*/
  #endif
#endif 

#define BIT_RATE 9600 /*speed uart in bit/s, default 9600 bit/s*/
#define UART_IBRD ((unsigned char) (FUARTCLK/(16*BIT_RATE)))
#define UART_FBRD ((unsigned char) ((FUARTCLK/(16*BIT_RATE) - UART_IBRD)*64))

#define GPIO_PIN10  (1 << 10)
#define GPIO_PIN11  (1 << 11) 
/*----------------------------------------------------------------------------
  Initialize UART pins, Baudrate (default LDM system - UART2 9600@16MHz)
 *----------------------------------------------------------------------------*/
void SER_Init (void) {
 /* configurate GPIO for UART2: TxD - PF.10, RxD - PF.11*/
  NT_COMMON_REG->GPIODENF |= (GPIO_PIN10 | GPIO_PIN11);   /* enable GPIO pins PF.10, PF.11                */
  NT_COMMON_REG->GPIOPCTLF &= ~(0xF << 20);               /* select alternale function 0 for PF.10, PF.11 */
  NT_COMMON_REG->GPIOPCTLF |=  (0x0 << 20); 
  NT_GPIOF->ALTFUNCSET = (GPIO_PIN10 | GPIO_PIN11);       /* enable alternate function for PF.10, PF.11   */

 /* configurate UART2*/
  NT_COMMON_REG->UART_CLK |= (1 << 16);         /* enable clock UART2 devider is disable  */
  NT_COMMON_REG->PER_RST1 |= (0x80 << 2);       /* disable reset UART2 (enable UART2)     */
  NT_COMMON_REG->UART_SPI_CLK_SEL &= ~(3 << 4); /* select source clock UART2 - OSCillator */
  NT_COMMON_REG->UART_SPI_CLK_SEL |= (1 << 4);  /* on board LDMSYSTEM OSC = 16 MHz        */
  /* 9600 baud, 8 data bits, 1 stop bit, no flow control */  
  NT_UART2->IBRD = UART_IBRD;                   
  NT_UART2->FBRD = UART_FBRD;
  NT_UART2->LCR_H |= 0x70;                      /* 8 data bits, no flow control */
  NT_UART2->CR |= (0x01 << 8) | 0x1;            /* enable RX, TX                */
}


/*----------------------------------------------------------------------------
  Write character to Serial Port
 *----------------------------------------------------------------------------*/
int MyLowLevelPutchar(int x){
  while (!(NT_UART2->FR & FR_BUSY_Pos));       /* while transmiter is BUSY */
  NT_UART2->DR_bit.DATA = (x & 0x1FF);
  return (x);
}


/*----------------------------------------------------------------------------
  Read character from Serial Port   (blocking read)
 *----------------------------------------------------------------------------*/
int MyLowLevelGetchar(){
  while (!(NT_UART2->FR & FR_RXFE_Pos));
  return (NT_UART2->DR & 0xFF);
}


#include "Serial.h"

#include "stdio.h"

int main()
{
  SER_Init();
  printf("Hello world");
  while (1);
}
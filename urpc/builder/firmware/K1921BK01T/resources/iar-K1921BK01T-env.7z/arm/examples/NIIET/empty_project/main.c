#include <NIIET\K1921BK01T.h> 
int main()
{

while (1);
}
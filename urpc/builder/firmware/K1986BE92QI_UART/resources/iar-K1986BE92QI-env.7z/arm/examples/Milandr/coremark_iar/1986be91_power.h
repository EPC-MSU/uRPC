#ifndef __1986BE91_POWER_H
#define __1986BE91_POWER_H

#include "cm3_macro.h"

typedef struct {
	__io_reg PVDCS;
} _power;

#endif /* __1986BE91_POWER_H */
